package com.gigmosaic.platform.product.api.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.openapitools.jackson.nullable.JsonNullable;
import java.io.Serializable;
import java.time.OffsetDateTime;
import jakarta.validation.constraints.NotNull;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * Product
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2024-03-08T00:04:48.467943-05:00[America/Toronto]")
public class Product implements Serializable {

  private static final long serialVersionUID = 1L;

  private Optional<String> id = Optional.empty();

  private String productName;

  private String details;

  private String category;

  private Optional<String> type = Optional.empty();

  private Optional<String> price = Optional.empty();

  private Optional<String> currency = Optional.empty();

  private Optional<String> sku = Optional.empty();

  private Optional<String> productAttribute = Optional.empty();

  private Optional<String> status = Optional.empty();

  private Optional<String> creationDate = Optional.empty();

  private Optional<String> updateDate = Optional.empty();

  public Product() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public Product(String productName, String details, String category) {
    this.productName = productName;
    this.details = details;
    this.category = category;
  }

  public Product id(String id) {
    this.id = Optional.of(id);
    return this;
  }

  /**
   * Product ID.
   * @return id
  */
  
  @Schema(name = "id", description = "Product ID.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("id")
  public Optional<String> getId() {
    return id;
  }

  public void setId(Optional<String> id) {
    this.id = id;
  }

  public Product productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * Product Name.
   * @return productName
  */
  @NotNull
  @Schema(name = "productName", description = "Product Name.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("productName")
  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public Product details(String details) {
    this.details = details;
    return this;
  }

  /**
   * Product details.
   * @return details
  */
  @NotNull
  @Schema(name = "details", description = "Product details.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }

  public void setDetails(String details) {
    this.details = details;
  }

  public Product category(String category) {
    this.category = category;
    return this;
  }

  /**
   * Product category.
   * @return category
  */
  @NotNull
  @Schema(name = "category", description = "Product category.", requiredMode = Schema.RequiredMode.REQUIRED)
  @JsonProperty("category")
  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    this.category = category;
  }

  public Product type(String type) {
    this.type = Optional.of(type);
    return this;
  }

  /**
   * Product Type.
   * @return type
  */
  
  @Schema(name = "type", description = "Product Type.", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("type")
  public Optional<String> getType() {
    return type;
  }

  public void setType(Optional<String> type) {
    this.type = type;
  }

  public Product price(String price) {
    this.price = Optional.of(price);
    return this;
  }

  /**
   * Get price
   * @return price
  */
  
  @Schema(name = "price", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("price")
  public Optional<String> getPrice() {
    return price;
  }

  public void setPrice(Optional<String> price) {
    this.price = price;
  }

  public Product currency(String currency) {
    this.currency = Optional.of(currency);
    return this;
  }

  /**
   * Get currency
   * @return currency
  */
  
  @Schema(name = "currency", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("currency")
  public Optional<String> getCurrency() {
    return currency;
  }

  public void setCurrency(Optional<String> currency) {
    this.currency = currency;
  }

  public Product sku(String sku) {
    this.sku = Optional.of(sku);
    return this;
  }

  /**
   * Get sku
   * @return sku
  */
  
  @Schema(name = "sku", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("sku")
  public Optional<String> getSku() {
    return sku;
  }

  public void setSku(Optional<String> sku) {
    this.sku = sku;
  }

  public Product productAttribute(String productAttribute) {
    this.productAttribute = Optional.of(productAttribute);
    return this;
  }

  /**
   * Get productAttribute
   * @return productAttribute
  */
  
  @Schema(name = "productAttribute", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("productAttribute")
  public Optional<String> getProductAttribute() {
    return productAttribute;
  }

  public void setProductAttribute(Optional<String> productAttribute) {
    this.productAttribute = productAttribute;
  }

  public Product status(String status) {
    this.status = Optional.of(status);
    return this;
  }

  /**
   * Get status
   * @return status
  */
  
  @Schema(name = "status", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("status")
  public Optional<String> getStatus() {
    return status;
  }

  public void setStatus(Optional<String> status) {
    this.status = status;
  }

  public Product creationDate(String creationDate) {
    this.creationDate = Optional.of(creationDate);
    return this;
  }

  /**
   * Get creationDate
   * @return creationDate
  */
  
  @Schema(name = "creationDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("creationDate")
  public Optional<String> getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Optional<String> creationDate) {
    this.creationDate = creationDate;
  }

  public Product updateDate(String updateDate) {
    this.updateDate = Optional.of(updateDate);
    return this;
  }

  /**
   * Get updateDate
   * @return updateDate
  */
  
  @Schema(name = "updateDate", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("updateDate")
  public Optional<String> getUpdateDate() {
    return updateDate;
  }

  public void setUpdateDate(Optional<String> updateDate) {
    this.updateDate = updateDate;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Product product = (Product) o;
    return Objects.equals(this.id, product.id) &&
        Objects.equals(this.productName, product.productName) &&
        Objects.equals(this.details, product.details) &&
        Objects.equals(this.category, product.category) &&
        Objects.equals(this.type, product.type) &&
        Objects.equals(this.price, product.price) &&
        Objects.equals(this.currency, product.currency) &&
        Objects.equals(this.sku, product.sku) &&
        Objects.equals(this.productAttribute, product.productAttribute) &&
        Objects.equals(this.status, product.status) &&
        Objects.equals(this.creationDate, product.creationDate) &&
        Objects.equals(this.updateDate, product.updateDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, productName, details, category, type, price, currency, sku, productAttribute, status, creationDate, updateDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Product {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    currency: ").append(toIndentedString(currency)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    productAttribute: ").append(toIndentedString(productAttribute)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    updateDate: ").append(toIndentedString(updateDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

